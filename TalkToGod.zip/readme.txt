Shalom/Salam walaikum/Peace be upon you,

Simply extract the file to a desired folder and run the setup.exe file and then once it is installed you are free to use it
Some Considerations:
If you find the application useful,consider buying me a coffee by donatin some amount to me in this site:

https://buymeacoffee.com/guidedone3b

Thanks and May God/Jesus bless you.

Amen/Amin